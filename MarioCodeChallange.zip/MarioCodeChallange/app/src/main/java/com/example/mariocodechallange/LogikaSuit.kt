package com.example.mariocodechallange

class LogikaSuit (private val callback: Callback)  {
    fun rumusSuit (pemain : Int, lawan: Int) {
        val status = when {
            pemain > lawan -> "Pemain Menang"
            pemain < lawan -> "Lawan Menang"
            else -> "Draw"
        }

        callback.kirimStatus(status)
    }
}