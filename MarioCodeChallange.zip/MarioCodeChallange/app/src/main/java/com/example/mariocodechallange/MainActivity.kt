package com.example.mariocodechallange

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.ContextCompat

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity(), Callback {
    lateinit var btnBatu: ImageView
    lateinit var btnKertas: ImageView
    lateinit var btnGunting: ImageView
    lateinit var btnRefresh: ImageView
    lateinit var dataStatus: ImageView
    lateinit var musuhBatu: ImageView
    lateinit var musuhKertas: ImageView
    lateinit var musuhGunting: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnBatu = findViewById(R.id.batu)
        btnKertas = findViewById(R.id.kertas)
        btnGunting = findViewById(R.id.gunting)
        btnRefresh = findViewById(R.id.refresh)
        dataStatus = findViewById(R.id.versus)
        musuhBatu = findViewById(R.id.batuLawan)
        musuhKertas = findViewById(R.id.kertasLawan)
        musuhGunting = findViewById(R.id.guntingLawan)


        val rumus = LogikaSuit(this)

        val btn = mutableListOf(btnBatu, btnGunting, btnKertas)
        btn.forEach {
            it.setOnClickListener {
                val data = mutableListOf("Batu","Gunting","Kertas")
                val index = (1..3).random()
                Toast.makeText(this,data[index],Toast.LENGTH_SHORT).show()

                when (btn) {
                    btnBatu -> {
                        btnBatu.setBackgroundDrawable(ContextCompat.getDrawable(this,R.drawable.select))
                        rumus.rumusSuit(1, index)
                    }
                    btnGunting -> {
                        btnGunting.setBackgroundDrawable(ContextCompat.getDrawable(this,R.drawable.select))
                        rumus.rumusSuit(2, index)
                    }
                    btnKertas -> {
                        btnKertas.setBackgroundDrawable(ContextCompat.getDrawable(this,R.drawable.select))
                        rumus.rumusSuit(3, index)
                    }

                }


            }

        }

        btnRefresh.setOnClickListener {
            dataStatus.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.vs))
        }
    }


    override fun kirimStatus(status: String) {
        when {
            status.contains("P") -> {
                dataStatus.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.p1menang))
            }
            status.contains("L") -> {
                dataStatus.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.p2menang))
            }
            status.contains("D") -> {
                dataStatus.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.draw))
            }
        }

    }

}

private fun View.setBackgroundDrawable() {}


