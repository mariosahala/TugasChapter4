package com.example.mariocodechallange

class LogikaSuit(private val callback: Callback) {
    fun rumusSuit (pemain: Int, lawan: Int) {
        val status = when {
            pemain == 1 && lawan == 2 || pemain == 2 && lawan == 3 || pemain == 3 && lawan == 1 ->  "Pemain Menang"
            pemain == 1 && lawan == 3 || pemain == 2 && lawan == 1 || pemain == 3 && lawan == 2 -> "Lawan Menang"
            else -> "Draw"
        }

        callback.kirimStatus(status)
    }
}